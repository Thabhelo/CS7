#Replace with your email. Surround it by double quotes
email = "conradkeya@gmail.com" 

def twenty_twenty_three(200,24,1):
    
    print(200*10+24-1) 

    """Come up with the most creative expression that evaluates to 2023,
    using only numbers and the +, *, and - operators. Use all three of 
    them only to get full credit. Do NOT use division.

    >>> twenty_twenty_three()
    2023
    """
    return twenty_twenty_three