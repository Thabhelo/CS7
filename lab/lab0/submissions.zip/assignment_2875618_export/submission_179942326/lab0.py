email = "n02220262v@students.nust.ac.zw"

def twenty_twenty_three(): 

    """Come up with the most creative expression that evaluates to 2023, using only numbers and the +, *, and - operators.
 >>> twenty_twenty_three() 
 2023 """ 

    return 2*1000+2*100+2*10+2+1-2*10**2

print(twenty_twenty_three())


	