#Replace with your email. Surround it by double quotes
email = "langelihle@usapschool.org" 

def twenty_twenty_three():

    a = 11
    b = 12
    c = a + b

    d = 20
    e = b * d

    f = b * e

    g = d * c

    h = f - g

    i = d * d

    j = h - i + c

    k = j - d

    """
    >>> twenty_twenty_three()
    2023
    """
    return k

twenty_twenty_three()
