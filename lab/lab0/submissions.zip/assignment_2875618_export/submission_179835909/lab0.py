#Replace with your email. Surround it by double quotes
email = "praise.n@usapschool.org" 

def twenty_twenty_three():
    """Come up with the most creative expression that evaluates to 2023,
    using only numbers and the +, *, and - operators.

    >>> twenty_twenty_three()
    2023
    """
    a = 11
    a *= 10
    a -= 9
    a *= 20
    a += 3
    
    return a
