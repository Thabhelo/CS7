#zibusisonyathi@gmail.com
from operator import mul, add, sub
def twenty_twenty_three(x):
	return sub(add(mul(mul(5, x), x), mul(2, x)), 17)

twenty_twenty_three(20)
