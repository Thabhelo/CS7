#Replace with your email. Surround it by double quotes
email = "terencempofu701@gmail.com"

def twenty_twenty_three():
    """Come up with the most creative expression that evaluates to 2023,
    using only numbers and the +, *, and - operators. Use all three of 
    them only to get full credit. Do NOT use division.

    >>> twenty_twenty_three()
    2023
    """
    return 10*10*10 + 10*10*10+ 111*3*3*0 - 459*3 + 20*1 + 1*3 + 10*10*10 + 10*10*10 - 1592 -1000 + 23 + 100*77+1+99 - 3500*2 +1146
