#Replace with your email. Surround it by double quotes
email = "lesliepande30@gmail.com" 

def twenty_twenty_three():
    """Come up with the most creative expression that evaluates to 2023,
    using only numbers and the +, *, and - operators. Use all three of 
    them only to get full credit. Do NOT use division.

    >>> twenty_twenty_three()
    2023
    """
    return (10**3)+(10**3)+2*15-7