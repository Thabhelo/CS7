#Replace with your email. Surround it by double quotes
email = "chantelle@usapschool.org" 

def twenty_twenty_three():
    """Come up with the most creative expression that evaluates to 2023,
    using only numbers and the +, *, and - operators. Use all three of 
    them only to get full credit. Do NOT use division.

    >>> twenty_twenty_three()
    2023
    """
    n = 2
    x = 1000
    y = 12
    z = (n * x) + (n * y) - 1
    return z
