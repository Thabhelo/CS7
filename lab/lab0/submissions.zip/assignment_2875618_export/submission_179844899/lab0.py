#Replace with your email. Surround it by double quotes
email = "jadeitegrey@gmail.com" 

def twenty_twenty_three():
        
        year = (((150*2)+(60-20)+1)*3)+1000
        print (year)
        return (year)
        
twenty_twenty_three()