#Replace with your email. Surround it by double quotes
from multiprocessing import Value


email = "kingigbozuruike@gmail.com" 

def twenty_twenty_three():
    answer = (((10 * 100) + (10 * 10)) * 2) - (59 * 3)

    return answer