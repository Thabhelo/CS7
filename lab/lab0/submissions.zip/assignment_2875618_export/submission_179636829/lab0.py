#Replace with your email. Surround it by double quotes
email = "chibonison@gmail.com" 

def twenty_twenty_three(a, b, c, d, e, f):
    """Come up with the most creative expression that evaluates to 2023,
    using only numbers and the +, *, and - operators. Use all three of 
    them only to get full credit. Do NOT use division.

    >>> twenty_twenty_three()
    2023
    """
    doone = a*b-c+(d*e)+f
    return doone
    
print(twenty_twenty_three(1000, 5, 3000, 11, 2, 1))