#Replace with your email. Surround it by double quotes
email = "ndrederek03@gmail.com" 

def twenty_twenty_three():
    """Come up with the most creative expression that evaluates to 2023,
    using only numbers and the +, *, and - operators. Use all three of 
    them only to get full credit. Do NOT use division.

    >>> twenty_twenty_three()
    2023
    """
    return (1 * 3) + (5 * 7) + (9 * 11) + (13 * 15) + (17 * 19) + (2 * 4 * 6 * 8) + (10 * 12) + (14 * 16) + (18 * 20) + (21 + 22 + 23 + 24 + 25 + 26 + 27 + 28 + 31 + 32 + 33) - (35 - 34 - 29 + 30) - (35 + 34 - 29 - 30)