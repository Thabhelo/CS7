email = "daphinemutanga52@gmail.com"
def twenty_twenty_three(email):
    letter_count = sum(1 for char in email if char.isalpha())
    sum1 = ((letter_count * 100) + 2 * letter_count + 23) - 244
    return print(sum1)
twenty_twenty_three(email)
