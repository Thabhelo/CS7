#Replace with your email. Surround it by double quotes
email = "kumwendainnocent6@gmail.com" 

def twenty_twenty_three():
    """Come up with the most creative expression that evaluates to 2023,
    using only numbers and the +, *, and - operators.
	
    >>> twenty_twenty_three = (1000*4//2) + 25 - 2 
    2023
    """
    return (2023)