# #Replace with your email. Surround it by double quotes
# email = "emziniwecode@gmail.com" 

# def twenty_twenty_three():
#     """Come up with the most creative expression that evaluates to 2023,
#     using only numbers and the +, *, and - operators. Use all three of 
#     them only to get full credit. Do NOT use division.

#     >>> twenty_twenty_three()
#     2023
#     """
#     return _____



a = 2
b = 0 
c = 3

d = "2"
e = "0"
f = "3"

print(a,b,a,c)
print(d+e+d+f)

dob = 2001
age = 22

current_year = dob + age
print(current_year)


z = '3202'
print(z[::-1]) # reversing text


zero = ["*****", "*   *", "*   *", "*   *", "*****"]
one = ["    *", "    *", "    *", "    *", "    *"]
two = ["*****", "    *", "*****", "*    ", "*****"]
three = ["*****", "    *", "*****", "    *", "*****"]

# Define a list of all the digit patterns
patterns = [zero, one, two, three]

# Loop through each row of the patterns and print them
for row in range(5):
    for digit in "2023":
        # Use the * operator to repeat the digit's pattern horizontally
        print(digit + " " * 2 + "".join([char * 2 for char in patterns[int(digit)][row]]), end="  ")
    print()





