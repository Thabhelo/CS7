

Email="pmasina309@gmail.com"

x=int(input("enter your age: "))

def twenty_twenty_three(value):
    
    u=str(x)
    
    n=len(u)
    
        
    if n<2:
        print (2*n*1000+2*n*10+(n+2))
        
        
    elif n>1 and n<3 :
       print( n*1000+n*10+n+(n-1))
      
        
    else:
        print("you have lived too long")
        
        
    return

        
    


twenty_twenty_three(x)




    