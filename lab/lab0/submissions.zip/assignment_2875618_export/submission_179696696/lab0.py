#Replace with your email. Surround it by double quotes
email = "andiledube020400@gmail.com" 
name = "Andile Dube"

def twenty_twenty_three():
    """Come up with the most creative expression that evaluates to 2023,
    using only numbers and the +, *, and - operators. Use all three of 
    them only to get full credit. Do NOT use division.

    >>> twenty_twenty_three()
    2023
    """
    return (3*1011)-(216+(397*2))
